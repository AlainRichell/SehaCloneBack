django.jQuery(document).ready(function($) {
    $('.select2').select2({
        placeholder: 'Buscar centro médico...',
        allowClear: true,
        width: '100%',
        language: {
            noResults: function() {
                return "No se encontraron resultados";
            },
            searching: function() {
                return "Buscando...";
            }
        }
    });
}); 