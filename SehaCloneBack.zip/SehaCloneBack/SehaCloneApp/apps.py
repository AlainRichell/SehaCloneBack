from django.apps import AppConfig


class SehacloneappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SehaCloneApp'
    verbose_name = 'لوحة'
